public class Emp
{
	private int empId;
	private String empName;
	private float empSal;
	static int empCount;
	
	private int getempId()
	{
		return empId;
	}
	
	private String getempName()
	{
		return empName;
	}
	private float getempSal()
	{
		return empSal;
	}
	
	public void setempId(int empId)
	{
		this.empId=empId;
	}
	

	public void setempName(String empName)
	{
		this.empName=empName;
	}
	

	public void setempSal(float empSal)
	{
		this.empSal=empSal;
	}
	
	public Emp() {
		
	}
	
	public Emp(int empId, String empName, float empSal) {
		
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		empCount++;
	}

	public String dispEmpInfo() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", empSal="
				+ empSal + "]";
	}
	
	public static  void getCount()
	{
		System.out.println("Emp Count is:" +empCount);
	}
    
}