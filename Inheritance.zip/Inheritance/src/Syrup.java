public class Syrup extends Medicine {
	public Syrup()
	{
		super();
	}
	public Syrup(String medname,String compName,float price,String expdate)
	{
		super(medname,compName,price,expdate);
	}
	public String dispMedInfo() {
		return super.dispMedInfo() +"\nShake well before use";
	}

}
