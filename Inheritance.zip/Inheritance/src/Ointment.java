public class Ointment extends Medicine {
	public Ointment()
	{
		super();
	}
	public Ointment(String medname,String compName,float price,String expdate)
	{
		super(medname,compName,price,expdate);
	}
	public String dispMedInfo() {
		return super.dispMedInfo() +"\n Only for external use";
	}

}
