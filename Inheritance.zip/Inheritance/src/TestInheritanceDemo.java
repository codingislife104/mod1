public class TestInheritanceDemo 
{
	public static void main(String [] args)
	{
		Employee e1=null;
		e1=new Employee(333,"devaki",60000.0F);
		WageEmp e2=null;
		e2=new WageEmp(555,"prasad",50000.0F,5,600);
		Employee e3=null;
		e3=new WageEmp(363,"kiran",60000.0F,4,450);
		
		WageEmp we=(WageEmp)e3;
		
		Employee chamu=new 	Employee(101,"Chamu",20220.0F);
		WageEmp  nanni=new 	WageEmp(102,"Nanni",50220.0F,400,23);
		System.out.println(" Emp Info: "+chamu.dispEmpInfo());
		System.out.println(" Emp Month Sal: "+chamu.calcEmpBasicSal());
		System.out.println(" Emp Annual Sal: "+chamu.calcEmpAnnualSal());
		
		System.out.println(" WageEmp Info: "+nanni.dispEmpInfo());
		System.out.println(" Wage Emp Month Sal: "+nanni.calcWageEmpBasicSal());
		System.out.println(" Wage Emp Annual Sal: "+nanni.calcWageEmpAnnualSal());
		
		System.out.println();
	
	}

}
