enum Seasons
{
	Summer,Rainy,Winter;
}
	public class TestEnumDemo {


	public static void main(String[] args) {
	          
		Seasons currentSeason=Seasons.Winter;
		System.out.println(" Its "+currentSeason);
	}

}
