public class Person 
{
	    private String firstName;
		private String lastName;
		private char gender;
		private int age;
		private float weight;
		
		public Person()
		{
			firstName="null";
			lastName="null";
			gender=' ';
			age=0;
			weight=0.0F;
		}
		
		public Person(String firstName, String lastName, char gender, int age,
				float weight) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
			this.age = age;
			this.weight = weight;
		}

		
		public String dispPerson() {
			return "Person Details:"
					+ "\nFirstName=" + firstName + " \nLastName=" + lastName
					+ " \nGender=" + gender + " \nAge=" + age + " \nWeight="
					+ weight ;
		}



		
	}



