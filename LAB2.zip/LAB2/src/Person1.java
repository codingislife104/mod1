public class Person1
{
	    private String firstName;
		private String lastName;
		private char gender;


	public String getfirstName()
	 {
		 return firstName;
	 }
	 
	 public String getlastName()
	 {
		 return lastName;
	 }
	 
	 public char getgender()
	 {
		 return gender;
	 }
	 
	 public void setfirstName(String firstName)
	 {
		  this.firstName=firstName;
	 }
	 
	 public void setlastName(String lastName)
	 {
		  this.lastName=lastName;
	 }
	 
	 public void setgender(char gender)
	 {
		 this.gender=gender;
	 }
	 
	 public Person1(String firstName, String lastName, char gender) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}

	public String dispPerson1() {
			return "Person Details:"
					+ "\nFirstName=" + firstName + " \nLastName=" + lastName
					+ " \nGender=" + gender ;
		}


}
