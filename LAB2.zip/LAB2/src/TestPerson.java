public class TestPerson {

	public static void main(String[] args)
	{
		String firstName=null;
		String lastName=null;
		char gender=' ';
		int age=0;
		float weight=0.0F;
		
		Person p= new Person("Divya","Bharathi",'F',20,85.55F);
		System.out.println(p.dispPerson());
		

	}

}

