
public class PersonMain {

	public static void main(String[] args) {
		
		String firstName=null;
		String lastName=null;
		char gender=' ';
		
		
		Person1 p= new Person1("Divya","Bharathi",'F');
		System.out.println(p.dispPerson1());
		

	}

}
