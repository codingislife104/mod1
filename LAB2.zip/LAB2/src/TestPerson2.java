public class TestPerson2 {

	public static void main(String[] args)
	{
		String firstName=null;
		String lastName=null;
		char gender=' ';
		String phoneno=null;
		
		Person2 p= new Person2("Divya","Bharathi",'F',"9878789875");
		System.out.println(p.dispPerson2());
	}

}
