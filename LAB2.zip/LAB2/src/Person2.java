public class Person2
{
	    private String firstName;
		private String lastName;
		private char gender;
		private String phoneno;
		
		public Person2()
		{
			firstName="null";
			lastName="null";
			gender=' ';
			phoneno="null";
		}
		
		public Person2(String firstName, String lastName, char gender,String phoneno) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.gender = gender;
			this.phoneno=phoneno;
		}

		
		public String dispPerson2() {
			return "Person Details:"
					+ "\nFirstName=" + firstName + " \nLastName=" + lastName
					+ " \nGender=" + gender + " \nPhone=" + phoneno  ;
		}
}



