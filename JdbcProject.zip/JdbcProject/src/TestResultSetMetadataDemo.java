import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TestResultSetMetadataDemo
{
	 public static void main(String[] args) 
	   {
			//Load oracle type 4 driver in memory
		   Connection conn=null;
		   ResultSet rs=null;
		   ResultSetMetaData rsmd=null;
		   Statement st=null;
		   try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			st=conn.createStatement();
			rs=st.executeQuery("SELECT * FROM  emp_142911");
			rsmd=rs.getMetaData();
			int colCount=rsmd.getColumnCount();
			System.out.println("No. of columns: "+colCount);
			for(int i=1;i<colCount;i++)
			{
				System.out.println(i+" Column Name: "+rsmd.getColumnName(i));
				System.out.println(i+" Column Type: "+rsmd.getColumnType(i));
				System.out.println(i+" Column Type Name: "+rsmd.getColumnTypeName(i));
				System.out.println(i+" Column Label: "+rsmd.getColumnLabel(1));
				System.out.println("**********");
			}
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
}
}
