import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestFileReadDataDemo 
{
	public static void main(String[] args)
	{
		/***********Which file?***********/
		File myFile=new File
				("D:/JavatalwadeWS/Day2Demos/src/Date.java");
		FileOutputStream fos=null;
		try
		{
		FileInputStream fis=new
				FileInputStream(myFile);
		fos=new FileOutputStream("MyDate.java");
			int data=fis.read();
		while(data!=-1)
		{
			fos.write(data);
			fos.flush();
			data=fis.read();
		}
		System.out.print("All data is written");
		}
		
		
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
			
		}
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	}


