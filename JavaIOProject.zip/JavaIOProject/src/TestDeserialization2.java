
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;


public class TestDeserialization2
{
	public static void main(String[] args)
	{
		ObjectInputStream ois;
		FileInputStream fis;
		Emp empl[]=new Emp[3];
		try {
				fis=new FileInputStream("EmpData.obj");
				ois=new ObjectInputStream(fis);
				for(int i=0;i<empl.length;i++)
				{
				Emp e1=(Emp)ois.readObject();
				System.out.println("Emp object is written in a file"+e1);
				}
			}
		catch (IOException | ClassNotFoundException e) 
		{
		    e.printStackTrace();
	    }
    }
	    
	  
  }
