import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestEmp 
{
	public static void main(String[] args)
	{
		try
		{
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		 System.out.println("Enter emp id: ");
		 int eid=Integer.parseInt(br.readLine());
		 System.out.println("Enter emp name: ");
		 String enm=br.readLine();
		 System.out.println("Enter emp sal: ");
		 float esl=Float.parseFloat(br.readLine());
		 
		 System.out.println(eid+" "+enm+" "+esl);
		 FileWriter fw=new FileWriter("EmpInfo.txt");
		 BufferedWriter bw=new BufferedWriter(fw);
		 Integer eIdS=new Integer(eid);
		 Float eslS=new Float(esl);   //Boxing
		 bw.write(eIdS.toString());
		 bw.write(enm);
		 bw.write(eslS.toString());
		 bw.newLine();
		 bw.flush();
		 
		 System.out.println("Emp info written" + " in a file");
	}
	catch(IOException ie)
	{
		ie.printStackTrace();
	}

}
}
