import java.util.Scanner;

public class TestModifyDate2
{
      public static void main(String[] args) 
      {
    	Scanner sc=new Scanner(System.in);
    	
		System.out.println("Enter Day :");
		int dayOfDoj=sc.nextInt();
		

		System.out.println("Enter Month :");
		int monOfDoj=sc.nextInt();
		

		System.out.println("Enter Year :");
		int yearOfDoj=sc.nextInt();
		
		Date chamuDOJ=new Date(dayOfDoj,monOfDoj,yearOfDoj);
        System.out.println("Your DOJ is:"+chamuDOJ.dispDate());
        
        System.out.println("Enter Day :");
		int dayOfDoj1=sc.nextInt();
		

		System.out.println("Enter Month :");
		int monOfDoj1=sc.nextInt();
		

		System.out.println("Enter Year :");
		int yearOfDoj1=sc.nextInt();
		
		Date chamsDOJ=new Date(dayOfDoj1,monOfDoj1,yearOfDoj1);
        System.out.println("Your DOJ is:"+chamsDOJ.dispDate());
        
        
       }

}

