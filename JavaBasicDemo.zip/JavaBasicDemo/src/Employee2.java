public class Employee2
{

	private int empid;
	private String empname;
	private float empsal;
	private char gender;
	
	public Employee2()
	{
		empid=0;
		empname=null;
		empsal=0.0F;
		gender=' ';
	}
	
	public Employee2(int id,String name,float sal,char gen)
	{
		empid=id;
		empname=name;
		empsal=sal;
		gender=gen;
	}
	
	
	public String dispDetails()
	{
		return (empid+","+empname+","+empsal+","+gender);
	}
	
	public float calcBasicSal()
	{
		return empsal;
	}
}


