import com.cg.bat.Batch;
import com.cg.stu.Student;

public class TestStudentDemo {

	public static void main(String[] args)
	{
		Batch javaBatch=new Batch("JEE_Propel_001","8.30 TO 6.00","Anjulatha");
		Batch vnvBatch=new Batch("VNV_PT_002","9.00 TO 6.00","Shilpa");
		Batch oraAppBatch=new Batch("OraApp_ABridge_003","9.00 TO 6.00","Sachin");
		
		Student student1=new Student(111,"Devaki",90,javaBatch);
		Student student2=new Student(222,"Prasad",95,javaBatch);
		Student student3=new Student(333,"Kiran",70,vnvBatch);
		Student student4=new Student(444,"Chamu",50,oraAppBatch);
		
		System.out.println(student1.dispStuInfo());
		System.out.println(student2.dispStuInfo());
		System.out.println(student3.dispStuInfo());
		System.out.println(student4.dispStuInfo());
		
		
		

	}

}
