import java.util.ArrayList;
import java.util.TreeSet;
public class TestIntTreeSetDemo {
       public static void main(String[] args)
       {
    	   TreeSet<Integer> intSet=new TreeSet<Integer>();
    	Integer i1=new Integer(10);
   		Integer i2=new Integer(15);
   		Integer i3=new Integer(5);
   		Integer i4=new Integer(50);
   		Integer i5=new Integer(5);
   		
   		intSet.add(i1);
   		intSet.add(i2);
   		intSet.add(i3);
   		intSet.add(i4);
   		intSet.add(i5);
   		
   		System.out.println("Without iterator");
   		System.out.println(intSet);
       }
}
