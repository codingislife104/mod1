import java.time.*;
import java.time.format.DateTimeFormatter;

public class TestDateDemo {
	public static void main(String[] args)
	{
		LocalDate today=LocalDate.now();
		System.out.println("Today date:"+today);
		System.out.println("***********");
		LocalDate myDoj=LocalDate.of(2010, 04, 03);
		System.out.println("My date of joining: "+myDoj);
		System.out.println("***************");
		String chamDoj="13-Dec-2017";
		DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate chamDojD=LocalDate.parse(chamDoj,myFormat);
		System.out.println(" Chams doj ="+chamDojD);
		System.out.println("***************");
		DateTimeFormatter  secondFormat=DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		String urDoj=chamDojD.format(secondFormat);
		System.out.println("...."+urDoj);
		
	    System.out.println("Difference");
	    Period period=Period.between(myDoj,today);
	    int years=period.getYears();
	    int month=period.getMonths();
	    int day=period.getDays();
	    
	    System.out.println("my EXP in CG is:"+years+"Years: "+month+"Months: "+day+"Days");
		
	}

}
