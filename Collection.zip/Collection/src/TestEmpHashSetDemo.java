import java.util.ArrayList;
import java.util.HashSet;
public class TestEmpHashSetDemo
{
    public static void main(String[] args)
	{
		 HashSet<Emp> empSet=new HashSet<Emp>();
		 
		   Emp e1=new Emp(111,"Chamu",4000.0F);
		   Emp e2=new Emp(222,"Nanni",5250.0F);
		   Emp e3=new Emp(333,"Devaki",90000.0F);
		   
		   empSet.add(e1);
		   empSet.add(e2);
		   empSet.add(e3);
		   for(Emp tempE:empSet)
		   {
			   System.out.println(tempE);
		   }
	}

}
